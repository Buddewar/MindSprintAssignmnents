package Modifiers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ArrayListAssignment {

	public static void main(String[] args)
	{
		ArrayList<String> al=new ArrayList();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Six Fruits: ");
		for(int i=0;i<6;i++)
		{
			al.add(sc.next());
		}
		System.out.println("Enter 2 cities: ");
		al.add(sc.next());
		al.add(sc.next());
		
		
		System.out.println("Enter 2 hobbies: ");
		al.add(sc.next());
		al.add(sc.next());
		
		
		System.out.println("The Array List: "+al);
		
		al.remove(al.size()-1);
		
		System.out.println("The Array List: "+al);
		
		al.contains("cricket");
		
		al.remove("hyd");
		
		al.remove("grape");
		
		System.out.println("4th and 5th Elements in AL: "+al.get(3)+" and "+al.get(4));
		
		
		al.set(al.indexOf("Singing"), "Dancing");
		
		Collections.reverse(al);

		al.set(4,"Kerala");
		
		al.set(2, "Pomagranate");
		
		
		



	}
}
