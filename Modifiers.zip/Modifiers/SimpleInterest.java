package Modifiers;

public class SimpleInterest {
	public double calculateSI(long p,float r,int t)
	{
		double interest=(p*t*r)/100;
		return interest;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long principal=9876;
		float rate=9.8f;
		int t=3;
		SimpleInterest obj=new SimpleInterest();
		double interest=obj.calculateSI(principal,rate,t);
		System.out.println("The interest is :"+ interest);
		System.out.println("The Total Amount is :"+ (interest+principal));

		
	}

}
