package Modifiers;
 
public class StringsAssignment {
	public static void main(String args[])
	{
		 String t = "Delhi";
		 String y = new String("Mumbai");
		 String o ="Mumbai";
		 String k = "Delhi";
		 String l = new String("Delhi");
		 String p = new String("Hello");
				 if(o.equals(l)){
					 System.out.println("true");
				 }
				 else{
					 System.out.println("false");
				 }
				 
				 if(o==l){
					 System.out.println("true");
				 }
				 else{
					 System.out.println("false");
				 }
				 
				 
		 if(y.equals(p)){
			 System.out.println("y and p true");
		 }
		 else{
			 System.out.println("y and p false");
		 }

		 if(y== p){
			 System.out.println("y and p true address");
		 }
		 else{
			 System.out.println("y and p false address");
		 }
		 if(t.equals(o)){
			 System.out.println("t and o true");
		 }
		 else{
			 System.out.println("t and o false");
		 }

		 
		 if(t== o){
			 System.out.println("t and o true address >>");
		 }
		 else{
			 System.out.println("t and o false address >>");
		 }
		 if(k.equals(y)){
			 System.out.println("k and y true");
		 }
		 else{
			 System.out.println("k and y false");
		 }

		 
		 if(k== y){
			 System.out.println("k and y true address >>");
		 }
		 else{
			 System.out.println("k and y false address >>");
		 }
		 
		 
		 if(p.equals(y)){
			 System.out.println("p and y are true");
		 }
		 else{
			 System.out.println("p and y are false");
		 }

		 
		 if(t== l){
			 System.out.println("t and l are having true address >>");
		 }
		 else{
			 System.out.println("t and l are having false address >>");
		 }
		 
	}
 
}