package Modifiers;


abstract class MNC{
	public abstract void leaves();
	public abstract void holidays();
	public MNC()
	{
		System.out.println("MNC Class");
	}
	public void method()
	{
		System.out.println("MNC class is Abstract class.");
	}
}

abstract class MindSprint extends MNC
{

	
	public abstract void leaves();
	@Override
	public void holidays() {
		System.out.println("The Public holidays are mentioned!!!");
		
	}
	
}

class Hello extends MindSprint
{

	@Override
	public void leaves() {
		System.out.println("All the leaves that you take are Unpaid Leaves!!");
	}
	
	public void LeaveRequest()
	{
		System.out.println("If you touch Manager Feet, Then you can get one day paid Leave!!");

	}
	
}

public class AbstractAssignment {

	public static void main(String[] args) {
		Hello mc;
		//MindSprint mc
		mc=new Hello();
		mc.holidays();
		mc.leaves();
//		Hello he=new Hello();
//		he.LeaveRequest();
		mc.LeaveRequest();

		
	
	}

}
