package Modifiers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListAssignment {

	public static void main(String[] args) {
		LinkedList<String> al=new LinkedList();
		al.add("May");
		al.add("June");
		al.add("July");
		al.add("August");
		al.add("April");
		al.add("November");
		
		al.addLast("December");
		
		al.addFirst("January");
		
		al.add(1,"March");
		al.add(1, "February");
		
		System.out.println(al);
		al.add(7,"September");
		System.out.println(al);
		al.add(8,"October");
		System.out.println(al);
		
		int id=al.indexOf("April");
		if(id!=3)
		al.remove(id);
		
		al.add(3,"April");
		
		System.out.println(al);


		System.out.println("\nEven months: ");

		for(int i=0;i<al.size();i++)
		{
			if(i%2!=0)
			{
				System.out.println(al.get(i));
			}
		}
		
		System.out.println("\nOdd months: ");

		for(int i=0;i<al.size();i++)
		{
			if(i%2!=1)
			{
				System.out.println(al.get(i));
			}
		}
		
		System.out.println("\nPrinting using Iterator:\n");

		Iterator<String> itr=al.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());

		}
		
		System.out.println("\n First Month: "+al.getFirst()+" and Last Month: "+ al.getLast());
		System.out.println("\n First Month: "+al.peekFirst()+" and Last Month: "+ al.peekLast());

		al.remove(10);
		System.out.println("\n"+al);
		
		System.out.println(al.pollFirst());
		System.out.println(al.pollLast());
		
		System.out.println("\n"+al);

		System.out.println("Contains Winter Momnth: ? "+ al.contains("February"));

		

	}

}
