package Modifiers;

public class CalculateAssignment {
	public int calculate(int a, int b,int c)
	{
		return (a+b+c);
	}
	public int calculate(int a, int b)
	{
		return (b-a);
	}
	public double calculate(double a, int b)
	{
		return (double)(a/b);
	}
	public int calculate(double a, double b)
	{
		return (int) (a*b);
	}
	public boolean even(int a)
	{
		if(a%2==0)
		{
			return true;
		}
		else return false;
	}
	
	public boolean prime(int a)
	{
		for(int i=2;i<a/2;i++)
		{
			if(a%i==0)
			{
				return false;
			}
		}
		return true;
		
	}
	

	public static void main(String[] args) {
		
		CalculateAssignment obj =new CalculateAssignment();
		System.out.println("The sum of a, b, c :"+ obj.calculate(20, 30, 40));
		System.out.println("The subtraction of a, b :"+ obj.calculate(10,30));
		System.out.println("The division of a, b :"+ obj.calculate(80.0, 40));
		System.out.println("The multiplication of a, b :"+ obj.calculate(20.0, 40.0));
		System.out.println("The Number is Even ?:"+ obj.even(45));
		System.out.println("The Number is Prime ? :"+ obj.prime(17));

		
	}

}
