package Modifiers;

class THreadingAssignment
{
	synchronized public void add(int i,int j)
	{
		System.out.println("The Sum of two numbers i.e, "+i+" and "+j+" :"+(i+j));
	}

	synchronized public void factorial(int n)
	{
		int result=1;
		for(int i=1;i<=n;i++)
		{
			result=result*i;
		}
		System.out.println("the factorial of number "+n+" is: "+ result);
	}
}

class MyThread1 extends Thread{  
	THreadingAssignment a;  
	int i,j,n;
	MyThread1(THreadingAssignment a,int i,int j){  
		this.a=a;  
		this.i=i;
		this.j=j;
	}  
	
	MyThread1(THreadingAssignment a,int n){  
		this.a=a;
		this.n=n;
	}  
	

    public void run() { 
    	if(i==0 && j==0)
    	a.factorial(n);
    	if(n==0)
    	a.add(i, j);
    }
}


public class ThreadAssignment {

    public static void main(String[] args) {
    	THreadingAssignment a = new THreadingAssignment();

        MyThread1 t1 = new MyThread1(a, 4);
        MyThread1 t2 = new MyThread1(a, 6);
        MyThread1 t3 = new MyThread1(a, 4, 5);
        MyThread1 t4 = new MyThread1(a, 20, 10);

        t1.setName("thread - t1");
        t2.setName("thread - t2");
        t3.setName("thread - t3");
        t4.setName("thread - t4");

        try {
            t2.start();
            Thread.sleep(1000); 
            t4.start();
            Thread.sleep(1000); 
            t1.start();
            Thread.sleep(1000); 
            t3.start();
            Thread.sleep(1000); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}











//
//class myThread 
//{
//	synchronized public void add(int i,int j)
//	{
//		System.out.println("The Sum of two numbers i.e, "+i+" and "+j+" :"+(i+j));
//	}
//	
//	synchronized public void factorial(int n)
//	{
//		int result=1;
//		for(int i=1;i<=n;i++)
//		{
//			result=result*i;
//		}
//		System.out.println("the factorial of number "+n+" is: "+ result);
//	}
//	
//}
//
//class MyThreadP1 extends Thread{  
//	myThread t;  
//	MyThreadP1(myThread t){  
//		this.t=t;  
//	}  
//	public void run(){  
//		System.out.println("Into the MyThread P1 run() method");
//		t.factorial(4);  
//	}  	  
//	}  
//
//class MyThreadP2 extends Thread{  
//	myThread t;  
//	MyThreadP2(myThread t){  
//		this.t=t;  
//	}  
//	public void run(){  
//		System.out.println("Into the MyThread P2 run() method");
//		t.factorial(6);  
//	}  	  
//	} 
//
//class MyThreadP3 extends Thread{  
//	myThread t;  
//	MyThreadP3(myThread t){  
//		this.t=t;  
//	}  
//	public void run(){  
//		System.out.println("Into the MyThread P3 run() method");
//		t.add(4,5);  
//	}  	  
//	} 
//
//class MyThreadP4 extends Thread{  
//	myThread t;  
//	MyThreadP4(myThread t){  
//		this.t=t;  
//	}  
//	public void run(){  
//		System.out.println("Into the MyThread P4 run() method");
//		t.add(20,10);  
//	}  	  
//	} 
//public class ThreadAssignment {
//
//	public static void main(String[] args) {
//		myThread t1=new myThread();
//		
//		MyThreadP2 p2=new MyThreadP2(t1);
//		MyThreadP4 p4=new MyThreadP4(t1);
//		MyThreadP1 p1=new MyThreadP1(t1);
//		MyThreadP3 p3=new MyThreadP3(t1);
//		
//		p2.setName("T2");
//		p4.setName("T4");
//		p1.setName("T1");
//		p3.setName("T3");
//		
//		p2.start();
//		p4.start();
//		p1.start();
//		p3.start();
//		
//		
//		
//		
//	}
//
//}
