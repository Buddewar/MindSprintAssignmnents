package Modifiers;

public class StaticAssignment {
	static int discount=5;

	int product_id;
	String name;
	int price;
	String Brand;
	StaticAssignment(int id,String Name,int p,String brand)
	{
		product_id=id;
		name=Name;
		price=p;
		Brand=brand;
	}
	
	
	public void original()
	{
	System.out.println("The Original Price: "+price+" and original discount: "+discount);

	}
	public void Print()
	{
		System.out.println("Product ID: "+product_id+" Name: "+name+" ");
		System.out.println("The Original Price: "+price+" and the Price after discount: "+(price-(price*discount)/100));
	}
	
	
	

	public static void main(String[] args) {
		
		System.out.println("Before Festive Season: ");

		StaticAssignment obj1=new StaticAssignment(100,"Product 1",200,"EarPhones");
		StaticAssignment obj2=new StaticAssignment(101,"Product 2",500,"HeadSet");

		StaticAssignment obj3=new StaticAssignment(102,"Product 3",100,"Rasgulla");

		StaticAssignment obj4=new StaticAssignment(103,"Product 4",150,"PaniPoori");
		obj1.original();
		obj2.original();

		obj3.original();

		obj4.original();
		
		obj1.Print();
		obj2.Print();
		obj3.Print();

		obj4.Print();
		System.out.println("\nAfter Festive Season: \n");

		obj2.discount=10;
		obj1.Print();
		obj2.Print();
		
		obj3.discount=30;
		obj3.Print();
		obj4.Print();

		

		
	}

}
