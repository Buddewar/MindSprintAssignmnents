package Modifiers;

public class FunctionOverloadingAssignment {
	public int calculate(long d)
	{
		long result=(long) (0.5*d*d);
		return (int)result;
	}
	public int calculate(float r)
	{
		double result=3.14*r*r;
		return (int)result;
	}
	public float calculate(int l,int b)
	{
		int result=l*b;
		return (float)result;
	}
	public long calculate(int side)
	{
		int result=side*side;
		return (long)result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverloadingAssignment obj=new FunctionOverloadingAssignment();
		System.out.println("The Area of rhombus is : "+ obj.calculate(12L));
		System.out.println("The Area of Circle is : "+ obj.calculate(4.5f));
		System.out.println("The Area of rectangle is : "+ obj.calculate(12,10));

		System.out.println("The Area of Square is : "+ obj.calculate(12));


	}

}
