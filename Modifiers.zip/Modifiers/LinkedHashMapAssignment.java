package Modifiers;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapAssignment {
	public static void main(String[] args) {
	Map<Integer,String> linkedmap= new LinkedHashMap<Integer,String>();
	linkedmap.put(101,"India");
	linkedmap.put(102,"Pak");
	linkedmap.put(103,"US");
	linkedmap.put(104,"SA");
	linkedmap.put(105,"AUS");
	linkedmap.put(106,"NZ");
	linkedmap.put(107,"NEP");
	linkedmap.put(108,"SL");
	linkedmap.put(109,"ENG");
	linkedmap.put(110,"ZIM");
	
	System.out.println("\nAll the Keys: \n");

	for (Integer key : linkedmap.keySet()) {
		System.out.println(key);
		
	}
	System.out.println("\nAll the values: \n");

	for (String key : linkedmap.values()) {
		System.out.println(key);
		
	}
	
	System.out.println("India Exists ?: "+linkedmap.containsValue("India"));
	
	System.out.println("45 Exists ?: "+linkedmap.containsKey(45));
	
	linkedmap.remove(102);  /// removing pak
	
	System.out.println(linkedmap);

	
	
	Map<Integer,String> statemap= new LinkedHashMap<Integer,String>();
	
	statemap.put(01, "Hyd");
	statemap.put(02, "Delhi");
	statemap.put(03, "NY");
	
	linkedmap.putAll(statemap);
	
	
	System.out.println(linkedmap);
	
	linkedmap.remove(3);

	
	System.out.println(linkedmap);

	System.out.println("Is Map Empty ?:"+linkedmap.isEmpty());
	
	
	linkedmap.clear();
	
	System.out.println(linkedmap);

	

	}
}
