package com.assignment.demo.model;

import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Book")
@EnableTransactionManagement
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "book_id")
	private int Book_id;
	
	@Column(name = "title")
	private String title;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "publish_year")
	private int publish_year;

	public int getId() {
		return Book_id;
	}
	public void setId(int Book_id) {
		this.Book_id = Book_id;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getpublish() {
		return publish_year;
	}
	public void setpublish(int publish_year) {
		this.publish_year = publish_year;
	}
	
	
	

	
}

