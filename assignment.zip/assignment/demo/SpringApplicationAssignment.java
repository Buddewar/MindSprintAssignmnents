package com.assignment.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableTransactionManagement
public class SpringApplicationAssignment {
	
		public static void main(String[] args) {
			SpringApplication.run(SpringApplicationAssignment.class, args);
		}

}
