package com.assignment.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.demo.model.Book;
import com.assignment.demo.repository.BookRepository;

@RestController
@RequestMapping("Book")
public class BookController {
	@Autowired
	BookRepository br;
	//get all Books (working)
		@GetMapping("allBooks")
		public List<Book> getAllBooks()
		{
			List<Book> book=(List<Book>) br.findAll();
			return book;
		}
	
	// insert new Book into database (not working)
		@PostMapping("add")
		public Book addBook(@RequestBody Book book)
		{
			return br.save(book);
		}
		
		// get particular Book by their ID  (working)
		@GetMapping("Book/{id}")
		public Optional<Book> getBookId(@PathVariable int id)
		{
			return br.findById(id);
		}
		
		// update existing Book (working)
		@PutMapping("update/{id}")
		public Book updateBook(@RequestBody Book book)
		{
			return br.save(book);
		}
		
		// delete particular book from database (working)
		@DeleteMapping("delete/{id}")
		public void deleteBook(@PathVariable int id)
		{
			br.deleteById(id);
		}
		@DeleteMapping("deleteAll")

		public void delete()
		{
			br.deleteAll();
		}
	

}
